package com.campusland.respository.models;

import com.campusland.respository.models.Cliente;
import com.campusland.respository.models.Producto;
import java.time.LocalDate;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Impuestos {
    private int id_impuesto;
    private Producto producto;
    private LocalDate periodo_fiscal;
    private double annio;

    public Impuestos(int id_impuesto,Producto producto, LocalDate periodo_fiscal, double annio) {
        this.id_impuesto = id_impuesto;
        this.producto = producto;
        this.periodo_fiscal = periodo_fiscal;
        this.annio = annio;
   
    }
    
    public double obtenerImpuesto(){
        return this.getProducto().getPrecioVenta() * 0.19;
    }
    
}
