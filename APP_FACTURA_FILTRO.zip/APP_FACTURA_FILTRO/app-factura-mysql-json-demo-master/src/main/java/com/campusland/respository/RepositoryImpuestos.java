package com.campusland.respository;

import com.campusland.exceptiones.facturaexceptions.FacturaExceptionInsertDataBase;
import com.campusland.respository.models.Factura;
import com.campusland.respository.models.Impuestos;
import java.util.List;

public interface RepositoryImpuestos {
    
    List<Impuestos> listar();
    
    void crear(Impuestos impuesto)throws FacturaExceptionInsertDataBase;
}

