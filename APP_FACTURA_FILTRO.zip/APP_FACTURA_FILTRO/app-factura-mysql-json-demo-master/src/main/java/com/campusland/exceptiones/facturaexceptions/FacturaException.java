package com.campusland.exceptiones.facturaexceptions;

public class FacturaException  extends Exception {

    public FacturaException(String mensaje) {
        super(mensaje);
    }
    
    
}
